<?php
    header("location: ./public");
?>
   